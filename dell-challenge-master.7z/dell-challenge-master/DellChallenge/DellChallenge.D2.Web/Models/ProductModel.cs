﻿namespace DellChallenge.D2.Web.Models
{
    public class ProductModel : NewProductModel
    {
        public string Id { get; set; }
    }
}
