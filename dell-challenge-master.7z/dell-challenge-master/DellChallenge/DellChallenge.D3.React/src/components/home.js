import React, { Component } from "react";

class Home extends Component {
  render() {
    return (
      <div className="Home text-center" >
          <h1 className="display-4">Welcome</h1>
          <p>Learn about <a href="https://reactjs.org/docs/getting-started.html">building Web apps with React</a>.</p>
      </div>
    );
  }
}

export default Home;
