import React, { Component } from "react";
class Privacy extends Component {
  render() {
    return (
      <React.Fragment>
          <h1 className="display-4">Privacy Policy</h1>
          <p>Use this page to detail your site's privacy policy.</p>
      </React.Fragment>
    );
  }
}
export default Privacy;
