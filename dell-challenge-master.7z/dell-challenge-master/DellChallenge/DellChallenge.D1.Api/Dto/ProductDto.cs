﻿namespace DellChallenge.D1.Api.Dto
{
    public class ProductDto : NewProductDto
    {
        public string Id { get; set; }
    }
}
