﻿namespace DellChallenge.D1.Api.Dto
{
    public class NewProductDto
    {
        public string Name { get; set; }
        public string Category { get; set; }
    }
}
